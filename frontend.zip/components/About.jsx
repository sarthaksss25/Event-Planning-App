import React from 'react'

const About = () => {
  return (
   <section className="about container">

    <h4>EVENTS</h4>
    <h2>ABOUT</h2>
    <p>Welcome to Event Planning, where dreams turn into unforgettable moments!

We specialize in creating extraordinary events that leave lasting impressions. Whether it's a wedding, corporate event, birthday celebration, or any special occasion, our dedicated team of event planners, designers, and coordinators work tirelessly to make your vision a reality.

At Event Planning, we believe that every event tells a story. From the initial concept to the final details, we take pride in delivering personalized, seamless, and creative experiences tailored to your needs. With a passion for excellence and a keen eye for detail, we ensure every element is meticulously planned and beautifully executed.</p>

   </section>
  )
}

export default About